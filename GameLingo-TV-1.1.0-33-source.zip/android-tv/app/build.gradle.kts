import java.util.Properties

plugins { id("com.android.application") }

val signing = Properties().apply {
    rootProject.file("../android/key.properties").inputStream().use { load(it) }
}

android {
    namespace = "com.mustafasenocak.gamelingo"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.mustafasenocak.gamelingo"
        minSdk = 24
        targetSdk = 36
        versionCode = 33
        versionName = "1.1.0"
    }
    // The dedicated TV track builds the same receiver source and brand assets.
    // No phone purchase flow, camera or PS5 connection engine runs on the TV.
    sourceSets.getByName("main") {
        java.srcDir("../../android/app/src/main/java/com/mustafasenocak/gamelingo/tv")
        res.srcDir("../../android/app/src/main/res")
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    signingConfigs {
        create("release") {
            keyAlias = signing.getProperty("keyAlias")
            keyPassword = signing.getProperty("keyPassword")
            val key = File(signing.getProperty("storeFile"))
            storeFile = if (key.isAbsolute) key else rootProject.file("../android/app/$key")
            storePassword = signing.getProperty("storePassword")
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"))
        }
    }
}
dependencies {
    implementation("com.google.zxing:core:3.5.4")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20251224")
}
