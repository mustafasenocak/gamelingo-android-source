package com.mustafasenocak.gamelingo.tv;

import org.json.JSONObject;
import org.junit.Test;
import static org.junit.Assert.*;

public class PremiumVerifierTest {
    private JSONObject proof(String store) throws Exception {
        return new JSONObject().put("store", store).put("verificationId", "private-test-reference");
    }
    private JSONObject apple() throws Exception {
        return new JSONObject().put("ok", true).put("premium", true)
            .put("productId", "gamelingo_monthly").put("statusCode", 1)
            .put("jwsVerified", true).put("revoked", false).put("upgraded", false)
            .put("checkedAt", "2026-11-19T18:00:00.000Z")
            .put("expiresAt", "2026-11-20T18:00:00.000Z");
    }
    private JSONObject google() throws Exception {
        return new JSONObject().put("ok", true).put("premium", true)
            .put("productId", "gamelingo_monthly")
            .put("packageName", "com.mustafasenocak.gamelingo")
            .put("subscriptionState", "SUBSCRIPTION_STATE_ACTIVE")
            .put("checkedAt", "2026-11-19T18:00:00.000Z")
            .put("expiresAt", "2026-11-20T18:00:00.000Z");
    }
    private void rejected(JSONObject result, String store, String code) throws Exception {
        PremiumVerifier v = new PremiumVerifier((path, body) -> result, () -> 100L);
        try { v.verify(proof(store)); fail("Invalid subscription granted TV access"); }
        catch (PremiumVerifier.Failure error) { assertEquals(code, error.code); }
    }
    @Test public void missingOrForgedPhonePremiumDoesNotContactBackend() throws Exception {
        PremiumVerifier v = new PremiumVerifier((path, body) -> { throw new AssertionError("No store proof"); }, () -> 0L);
        for (JSONObject input : new JSONObject[]{null, new JSONObject().put("premium", true),
                proof("fake_store"), proof("apple").put("verificationId", "x\ny-secret")}) {
            try { v.verify(input); fail("Unverified phone flag accepted"); }
            catch (PremiumVerifier.Failure error) { assertEquals("premium_required", error.code); }
        }
    }
    @Test public void storeReferencesGoOnlyToTheCorrectVerificationEndpoint() throws Exception {
        for (String store : new String[]{"apple", "google_play"}) {
            PremiumVerifier v = new PremiumVerifier((path, body) -> {
                assertEquals(store.equals("apple") ? "/apple/subscription/verify" : "/google/subscription/verify", path);
                assertEquals(1, body.length());
                assertEquals("private-test-reference", body.getString(store.equals("apple") ? "transactionId" : "purchaseToken"));
                return store.equals("apple") ? apple() : google();
            }, () -> 100L);
            assertEquals(300100L, v.verify(proof(store)));
        }
    }
    @Test public void unverifiedRevokedUpgradedWrongProductAndInactiveAppleAreDenied() throws Exception {
        rejected(apple().put("jwsVerified", false), "apple", "premium_required");
        rejected(apple().put("revoked", true), "apple", "premium_required");
        rejected(apple().put("upgraded", true), "apple", "premium_required");
        rejected(apple().put("productId", "other_product"), "apple", "premium_required");
        rejected(apple().put("premium", false), "apple", "premium_required");
        for (int status : new int[]{0, 2, 3, 5}) rejected(apple().put("statusCode", status), "apple", "premium_required");
    }
    @Test public void expiryLimitsAccessAndGraceNeedsFreshAuthoritativeStatus() throws Exception {
        JSONObject soon = apple().put("expiresAt", "2026-11-19T18:00:10.000Z");
        assertEquals(10100L, new PremiumVerifier((p, b) -> soon, () -> 100L).verify(proof("apple")));
        rejected(apple().put("expiresAt", "2026-11-19T17:59:59.000Z"), "apple", "premium_required");
        JSONObject grace = apple().put("statusCode", 4).put("expiresAt", "2026-11-18T18:00:00.000Z");
        assertEquals(300100L, new PremiumVerifier((p, b) -> grace, () -> 100L).verify(proof("apple")));
        rejected(apple().put("checkedAt", "invalid"), "apple", "subscription_check_failed");
    }
    @Test public void googleWrongAppAndUnpaidStatesAreDenied() throws Exception {
        rejected(google().put("packageName", "other.app"), "google_play", "premium_required");
        for (String state : new String[]{"SUBSCRIPTION_STATE_EXPIRED", "SUBSCRIPTION_STATE_PENDING", "SUBSCRIPTION_STATE_ON_HOLD", "SUBSCRIPTION_STATE_PAUSED"}) {
            rejected(google().put("subscriptionState", state), "google_play", "premium_required");
        }
        JSONObject cancelled = google().put("subscriptionState", "SUBSCRIPTION_STATE_CANCELED");
        assertEquals(300100L, new PremiumVerifier((p, b) -> cancelled, () -> 100L).verify(proof("google_play")));
    }
    @Test public void networkFailureNeverUsesPhoneOrOfflineCache() throws Exception {
        PremiumVerifier v = new PremiumVerifier((p, b) -> { throw new java.io.IOException("offline"); }, () -> 0L);
        try { v.verify(proof("apple")); fail("Offline subscription accepted"); }
        catch (PremiumVerifier.Failure error) { assertEquals("subscription_check_failed", error.code); }
    }
    @Test public void reviewAccessNeedsItsOwnServerVerifiedScopeAndExpiry() throws Exception {
        JSONObject review = new JSONObject().put("store", "google_review")
                .put("verificationId", "00112233445566778899AABBCCDDEEFF");
        JSONObject response = new JSONObject().put("ok", true).put("reviewAccess", true)
                .put("scope", "tv_receiver").put("packageName", "com.mustafasenocak.gamelingo")
                .put("checkedAt", "2026-11-19T18:00:00.000Z")
                .put("expiresAt", "2026-11-19T18:05:00.000Z");
        PremiumVerifier verifier = new PremiumVerifier((path, body) -> {
            assertEquals("/tv/review/verify", path);
            assertEquals(review.getString("verificationId"), body.getString("code"));
            return response;
        }, () -> 100L);
        assertEquals(300100L, verifier.verify(review));
        for (JSONObject invalid : new JSONObject[]{apple(), new JSONObject(response.toString()).put("scope", "other"),
                new JSONObject(response.toString()).put("reviewAccess", false),
                new JSONObject(response.toString()).put("expiresAt", "2026-11-19T17:00:00.000Z")}) {
            try {
                new PremiumVerifier((p, b) -> invalid, () -> 0L).verify(review);
                fail("Unverified review grant accepted");
            } catch (PremiumVerifier.Failure error) { assertEquals("premium_required", error.code); }
        }
        try {
            new PremiumVerifier((p, b) -> { throw new java.io.IOException(); }, () -> 0L).verify(review);
            fail("Offline review accepted");
        } catch (PremiumVerifier.Failure error) { assertEquals("subscription_check_failed", error.code); }
    }
}
