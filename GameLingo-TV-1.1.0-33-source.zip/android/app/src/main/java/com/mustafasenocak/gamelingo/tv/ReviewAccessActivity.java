package com.mustafasenocak.gamelingo.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.*;
import android.provider.Settings;
import android.text.InputFilter;
import android.text.InputType;
import android.view.WindowManager;
import android.widget.*;
import java.util.Locale;

/** Private review credentials are entered manually, never bundled or persisted. */
public final class ReviewAccessActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status;
    private final Runnable refresh = new Runnable() {
        @Override public void run() { status.setText(ReceiverService.status); handler.postDelayed(this, 500); }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SECURE);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(24), dp(48), dp(24));
        scroll.addView(root);
        setContentView(scroll);
        root.addView(text("İnceleme erişimi / Review access", 24));
        root.addView(text("Bu alan yalnızca yetkili mağaza incelemesi içindir. Normal TV kullanımı Premium gerektirir.\nFor authorized store review only. Enter the private code from Play Console App access. No purchase, phone or PS5 is needed for the receiver test.", 16));
        EditText code = new EditText(this);
        code.setHint("Özel inceleme kodu / Private review code");
        code.setContentDescription("Private review code");
        code.setTextColor(Color.WHITE); code.setHintTextColor(0xFFCEC4E0);
        code.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        code.setSingleLine(true); code.setSaveEnabled(false);
        code.setFilters(new InputFilter[]{new InputFilter.LengthFilter(64)});
        if (Build.VERSION.SDK_INT >= 26) code.setImportantForAutofill(android.view.View.IMPORTANT_FOR_AUTOFILL_NO_EXCLUDE_DESCENDANTS);
        root.addView(code);
        EditText sample = new EditText(this);
        sample.setText("Game Lingo · Türkçe altyazı testi.");
        sample.setHint("Altyazı metni / Caption text");
        sample.setTextColor(Color.WHITE); sample.setTextSize(17);
        sample.setSingleLine(true); sample.setFilters(new InputFilter[]{new InputFilter.LengthFilter(180)});
        root.addView(sample);
        Button start = new Button(this);
        start.setText("Testi başlat / Start receiver test"); start.setAllCaps(false);
        root.addView(start);
        start.setOnClickListener(view -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Önce ana ekrandan altyazı iznini açın. / Enable overlay permission from the main screen first.", Toast.LENGTH_LONG).show();
                return;
            }
            if (ReceiverService.running) {
                Toast.makeText(this, "Önce mevcut bağlantıyı kapatın. / Stop the current session first.", Toast.LENGTH_LONG).show();
                return;
            }
            String privateCode = code.getText().toString().replaceAll("[\\s-]", "").toUpperCase(Locale.ROOT);
            if (!privateCode.matches("[A-F0-9]{32}")) {
                code.setError("Geçerli inceleme kodunu girin. / Enter the complete private code.");
                return;
            }
            String caption = sample.getText().toString().trim();
            if (caption.isEmpty()) { sample.setError("Bir altyazı yazın. / Enter caption text."); return; }
            Intent service = new Intent(this, ReceiverService.class)
                    .setAction(ReceiverService.REVIEW).putExtra("reviewCode", privateCode).putExtra("reviewCaption", caption);
            code.setText("");
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        });
        Button stop = new Button(this);
        stop.setText("Testi durdur / Stop test"); stop.setAllCaps(false);
        stop.setOnClickListener(view -> {
            ReceiverService.status = "Test durduruldu. / Review test stopped.";
            stopService(new Intent(this, ReceiverService.class));
        });
        root.addView(stop);
        status = text("", 16); root.addView(status);
        root.addView(text("Test gerçek TV alıcısına şifreli bağlantı kurar ve abonelik yerine özel inceleme kodunu sunucuda doğrular. Altyazıyı HDMI veya ana ekran üzerinde kontrol edin. Oturum 10 dakika sonra kapanır; aynı özel kodla yeniden başlatılabilir.\nThe fixture sends captions through the production TLS receiver. Switch to Home or HDMI to inspect the overlay. Stop here or on the main screen. The 10-minute session can be restarted with the same reusable code. No subscription is created.", 15));
        code.requestFocus();
    }
    private TextView text(String value, int size) {
        TextView text = new TextView(this); text.setText(value); text.setTextSize(size); text.setTextColor(Color.WHITE);
        text.setPadding(0, dp(6), 0, dp(8)); return text;
    }
    private int dp(int n) { return Math.round(n * getResources().getDisplayMetrics().density); }
    @Override public void onResume() { super.onResume(); handler.post(refresh); }
    @Override public void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
}
