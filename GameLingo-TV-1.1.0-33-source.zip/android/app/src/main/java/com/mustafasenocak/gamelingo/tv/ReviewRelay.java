package com.mustafasenocak.gamelingo.tv;

import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.cert.X509Certificate;
import javax.net.ssl.*;

/** Review fixture uses the production pinned-TLS receiver and its server-side gate.
 * No credential or unlocked state is saved. This is explicitly disclosed to Play. */
final class ReviewRelay implements AutoCloseable {
    interface Listener { void status(String message); void finished(); }
    private volatile boolean closed;
    private volatile SSLSocket socket;
    private final Listener listener;
    ReviewRelay(Listener listener) { this.listener = listener; }
    void start(String privateCode, String sample) {
        new Thread(() -> run(privateCode, sample), "GameLingoReviewRelay").start();
    }
    private void run(String code, String sample) {
        try {
            String raw = "";
            for (int i = 0; i < 150 && !closed; i++) {
                raw = ReceiverService.pairingUri;
                if (!raw.isEmpty()) break;
                Thread.sleep(100);
            }
            if (closed) return;
            Uri uri = Uri.parse(raw);
            String host = uri.getQueryParameter("host"), pin = uri.getQueryParameter("pin");
            String token = uri.getQueryParameter("key");
            int port = Integer.parseInt(uri.getQueryParameter("port"));
            SSLContext tls = SSLContext.getInstance("TLS");
            tls.init(null, new TrustManager[]{new X509TrustManager() {
                public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
                public void checkClientTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException {
                    throw new java.security.cert.CertificateException("Client certificates unsupported");
                }
                public void checkServerTrusted(X509Certificate[] c, String a) throws java.security.cert.CertificateException {
                    try {
                        if (c.length != 1) throw new Exception();
                        StringBuilder actual = new StringBuilder();
                        for (byte b : MessageDigest.getInstance("SHA-256").digest(c[0].getEncoded()))
                            actual.append(String.format(java.util.Locale.ROOT, "%02x", b & 255));
                        if (!actual.toString().equals(pin)) throw new Exception();
                    } catch (Exception error) { throw new java.security.cert.CertificateException("TV pin mismatch"); }
                }
            }}, null);
            socket = (SSLSocket) tls.getSocketFactory().createSocket();
            socket.connect(new java.net.InetSocketAddress(host, port), 5000);
            socket.setSoTimeout(25000);
            socket.startHandshake();
            BufferedInputStream input = new BufferedInputStream(socket.getInputStream());
            send(new JSONObject().put("v", 2).put("type", "hello").put("key", token)
                    .put("subscription", new JSONObject().put("store", "google_review").put("verificationId", code)));
            JSONObject response = new JSONObject(PairingServer.readLine(input));
            if (!"ready".equals(response.optString("type"))) {
                listener.status("İnceleme kodu doğrulanamadı. / Review access denied.");
                return;
            }
            listener.status("İnceleme erişimi açık. / Review access active. Home veya HDMI ile altyazıyı diğer ekranlarda test edebilirsiniz.");
            long sequence = 0;
            long deadline = System.nanoTime() + 10 * 60 * 1000000000L;
            while (!closed && System.nanoTime() < deadline) {
                long id = ++sequence;
                JSONArray regions = new JSONArray().put(new JSONObject()
                        .put("id", "review-subtitle").put("text", sample)
                        .put("x", .12).put("y", .81).put("w", .76).put("h", .12)
                        .put("cover", new JSONObject().put("x", .12).put("y", .81).put("w", .76).put("h", .12)));
                send(new JSONObject().put("v", 2).put("type", "scene").put("seq", id).put("frameId", id)
                        .put("sourceWidth", 1920).put("sourceHeight", 1080).put("durationMs", 3000).put("regions", regions));
                send(new JSONObject().put("v", 2).put("type", "ping"));
                response = new JSONObject(PairingServer.readLine(input));
                if (!"pong".equals(response.optString("type"))) throw new IOException("Review lease ended");
                Thread.sleep(1500);
            }
            if (!closed) listener.status("Test oturumu sona erdi. Aynı kodla yeniden başlayabilirsiniz. / Test session ended; the code is reusable.");
        } catch (Exception error) {
            if (!closed) listener.status("Test bağlantısı kapandı. TV internetini ve altyazı iznini kontrol edip yeniden deneyin. / Check TV network and overlay permission, then retry.");
        } finally { close(); listener.finished(); }
    }
    private void send(JSONObject value) throws Exception {
        if (closed) throw new IOException("Stopped");
        socket.getOutputStream().write((value.toString() + "\n").getBytes(StandardCharsets.UTF_8));
        socket.getOutputStream().flush();
    }
    @Override public void close() {
        closed = true;
        try { if (socket != null) socket.close(); } catch (IOException ignored) {}
    }
}
