package com.mustafasenocak.gamelingo.tv;

import org.json.JSONObject;
import java.io.*;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;
import java.util.function.LongSupplier;
import javax.net.ssl.HttpsURLConnection;

/** The television checks the store reference itself; a phone's Premium flag is not trusted. */
final class PremiumVerifier {
    interface Transport { JSONObject post(String path, JSONObject body) throws Exception; }
    static final class Failure extends Exception {
        final String code;
        Failure(String code) { super(code); this.code = code; }
    }
    private final Transport transport;
    private final LongSupplier elapsed;
    PremiumVerifier() { this(PremiumVerifier::request, () -> System.nanoTime() / 1000000L); }
    PremiumVerifier(Transport transport, LongSupplier elapsed) {
        this.transport = transport; this.elapsed = elapsed;
    }
    long now() { return elapsed.getAsLong(); }

    /** Returns a monotonic deadline, capped at five minutes and subscription expiry. */
    long verify(JSONObject proof) throws Failure {
        if (proof == null) throw new Failure("premium_required");
        String store = proof.optString("store", "");
        String reference = proof.optString("verificationId", "");
        if (store.equals("google_review")) return verifyReview(reference);
        if ((!store.equals("apple") && !store.equals("google_play")) ||
                reference.length() < 6 || reference.length() > 2000 ||
                reference.matches("(?s).*[\\s\\x00-\\x1f\\x7f].*")) {
            throw new Failure("premium_required");
        }
        boolean apple = store.equals("apple");
        try {
            JSONObject body = new JSONObject().put(apple ? "transactionId" : "purchaseToken", reference);
            JSONObject result = transport.post(apple ? "/apple/subscription/verify" : "/google/subscription/verify", body);
            if (!Boolean.TRUE.equals(result.opt("ok")) ||
                    !Boolean.TRUE.equals(result.opt("premium")) ||
                    !"gamelingo_monthly".equals(result.optString("productId"))) {
                throw new Failure("premium_required");
            }
            boolean grace = false;
            if (apple) {
                int status = result.optInt("statusCode", 0);
                if (!Boolean.TRUE.equals(result.opt("jwsVerified")) ||
                        !Boolean.FALSE.equals(result.opt("revoked")) ||
                        !Boolean.FALSE.equals(result.opt("upgraded")) ||
                        (status != 1 && status != 4)) throw new Failure("premium_required");
                grace = status == 4;
            } else {
                String state = result.optString("subscriptionState");
                if (!"com.mustafasenocak.gamelingo".equals(result.optString("packageName")) ||
                        !(state.equals("SUBSCRIPTION_STATE_ACTIVE") ||
                          state.equals("SUBSCRIPTION_STATE_IN_GRACE_PERIOD") ||
                          state.equals("SUBSCRIPTION_STATE_CANCELED"))) {
                    throw new Failure("premium_required");
                }
            }
            // Use server timestamps for expiry, then a monotonic clock locally.
            // Changing the TV's wall clock cannot extend a verified session.
            long checked = timestamp(result.optString("checkedAt"));
            long validity = 300000L;
            if (!grace) validity = Math.min(validity, timestamp(result.optString("expiresAt")) - checked);
            if (validity <= 0) throw new Failure("premium_required");
            return now() + validity;
        } catch (Failure error) {
            throw error;
        } catch (Exception error) {
            // Never log a store reference, response body or remote exception.
            throw new Failure("subscription_check_failed");
        }
    }

    private long verifyReview(String code) throws Failure {
        if (!code.matches("[A-F0-9]{32}")) throw new Failure("premium_required");
        try {
            JSONObject result = transport.post("/tv/review/verify", new JSONObject().put("code", code));
            if (!Boolean.TRUE.equals(result.opt("ok")) ||
                    !Boolean.TRUE.equals(result.opt("reviewAccess")) ||
                    !"tv_receiver".equals(result.optString("scope")) ||
                    !"com.mustafasenocak.gamelingo".equals(result.optString("packageName"))) {
                throw new Failure("premium_required");
            }
            long validity = Math.min(300000L, timestamp(result.optString("expiresAt"))
                    - timestamp(result.optString("checkedAt")));
            if (validity <= 0) throw new Failure("premium_required");
            return now() + validity;
        } catch (Failure error) { throw error; }
        catch (Exception error) { throw new Failure("subscription_check_failed"); }
    }

    private static long timestamp(String text) throws Failure {
        if (!text.matches("\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}\\.\\d{3}Z"))
            throw new Failure("subscription_check_failed");
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ROOT);
        format.setTimeZone(TimeZone.getTimeZone("UTC"));
        format.setLenient(false);
        ParsePosition position = new ParsePosition(0);
        Date value = format.parse(text, position);
        if (value == null || position.getIndex() != text.length()) throw new Failure("subscription_check_failed");
        return value.getTime();
    }

    private static JSONObject request(String path, JSONObject body) throws Exception {
        // The destination is fixed; neither the QR nor the phone can redirect a purchase token.
        HttpsURLConnection connection = (HttpsURLConnection) new URL("https://api.gamelingo.app" + path).openConnection();
        try {
            connection.setInstanceFollowRedirects(false);
            connection.setConnectTimeout(8000);
            connection.setReadTimeout(10000);
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setRequestProperty("Accept", "application/json");
            byte[] bytes = body.toString().getBytes(StandardCharsets.UTF_8);
            connection.setFixedLengthStreamingMode(bytes.length);
            try (OutputStream output = connection.getOutputStream()) { output.write(bytes); }
            int status = connection.getResponseCode();
            if (status >= 400 && status < 500) throw new Failure("premium_required");
            if (status != 200) throw new Failure("subscription_check_failed");
            try (InputStream input = connection.getInputStream(); ByteArrayOutputStream result = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[4096];
                for (int count; (count = input.read(buffer)) != -1;) {
                    if (result.size() + count > 65536) throw new IOException("Oversized verification response");
                    result.write(buffer, 0, count);
                }
                return new JSONObject(result.toString(StandardCharsets.UTF_8.name()));
            }
        } finally { connection.disconnect(); }
    }
}
