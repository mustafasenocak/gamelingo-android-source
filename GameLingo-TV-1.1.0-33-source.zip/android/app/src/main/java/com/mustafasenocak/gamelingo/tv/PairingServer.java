package com.mustafasenocak.gamelingo.tv;

import com.mustafasenocak.gamelingo.R;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Uri;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import org.json.JSONObject;
import org.json.JSONArray;
import java.io.*;
import java.math.BigInteger;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.*;
import java.security.spec.ECGenParameterSpec;
import java.util.*;
import javax.net.ssl.*;
import javax.security.auth.x500.X500Principal;

/** Captions require the scanned TV token and an independently verified Premium subscription. */
final class PairingServer implements AutoCloseable {
    interface Listener {
        void pairing(String uri);
        void connected();
        void subscriptionStatus(String message);
        void caption(String text, int durationMs, boolean top);
        void scene(TvScene scene);
        void ended(String reason);
    }
    private static final String ALIAS = "gamelingo_tv_tls_v2";
    private final Context context;
    private final Listener listener;
    private volatile boolean closed;
    private volatile SSLServerSocket server;
    private volatile SSLSocket client;
    private final String token;
    PairingServer(Context context, Listener listener) {
        this.context = context;
        this.listener = listener;
        byte[] bytes = new byte[32];
        new SecureRandom().nextBytes(bytes);
        token = Base64.encodeToString(bytes, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
    }
    void start() {
        Thread thread = new Thread(this::serve, "GameLingoTvTls");
        thread.setDaemon(true);
        thread.start();
    }
    private void serve() {
        String endReason = "Bağlantı kapandı. Yeniden eşleştirebilirsiniz.";
        boolean paired = false;
        try {
            ConnectivityManager manager = context.getSystemService(ConnectivityManager.class);
            LinkProperties links = manager.getLinkProperties(manager.getActiveNetwork());
            InetAddress address = links == null ? null : links.getLinkAddresses().stream()
                    .map(a -> a.getAddress()).filter(a -> a instanceof Inet4Address
                            && a.isSiteLocalAddress()).findFirst().orElse(null);
            if (address == null) throw new IOException("No private IPv4 network");
            KeyStore keys = KeyStore.getInstance("AndroidKeyStore");
            keys.load(null);
            // Retire the preview key: TLS signs a pre-hashed digest through NONEwithECDSA.
            if (keys.containsAlias("gamelingo_tv_tls_v1")) keys.deleteEntry("gamelingo_tv_tls_v1");
            if (!keys.containsAlias(ALIAS)) {
                KeyPairGenerator generator = KeyPairGenerator.getInstance(
                        KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore");
                generator.initialize(new KeyGenParameterSpec.Builder(ALIAS,
                        KeyProperties.PURPOSE_SIGN | KeyProperties.PURPOSE_VERIFY)
                        .setAlgorithmParameterSpec(new ECGenParameterSpec("secp256r1"))
                        .setDigests(KeyProperties.DIGEST_NONE,
                                KeyProperties.DIGEST_SHA256, KeyProperties.DIGEST_SHA384,
                                KeyProperties.DIGEST_SHA512)
                        .setCertificateSubject(new X500Principal("CN=Game Lingo TV"))
                        .setCertificateSerialNumber(BigInteger.ONE)
                        .setCertificateNotBefore(new Date(System.currentTimeMillis() - 86400000L))
                        .setCertificateNotAfter(new Date(System.currentTimeMillis() + 31536000000L))
                        .build());
                generator.generateKeyPair();
            }
            KeyManagerFactory factory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
            factory.init(keys, null);
            SSLContext tls = SSLContext.getInstance("TLS");
            tls.init(factory.getKeyManagers(), null, new SecureRandom());
            server = (SSLServerSocket) tls.getServerSocketFactory().createServerSocket(0, 4, address);
            server.setEnabledProtocols(Arrays.stream(server.getSupportedProtocols())
                    .filter(p -> p.equals("TLSv1.2") || p.equals("TLSv1.3")).toArray(String[]::new));
            server.setSoTimeout(1000);
            byte[] digest = MessageDigest.getInstance("SHA-256").digest(keys.getCertificate(ALIAS).getEncoded());
            StringBuilder pin = new StringBuilder();
            for (byte b : digest) pin.append(String.format(Locale.ROOT, "%02x", b & 255));
            String qr = new Uri.Builder().scheme("gamelingo-tv").authority("pair")
                    .appendQueryParameter("v", "2").appendQueryParameter("host", address.getHostAddress())
                    .appendQueryParameter("port", String.valueOf(server.getLocalPort()))
                    .appendQueryParameter("pin", pin.toString()).appendQueryParameter("key", token)
                    .appendQueryParameter("name", Build.MODEL).build().toString();
            if (closed) return;
            listener.pairing(qr);
            long deadline = android.os.SystemClock.elapsedRealtime() + 300000;
            while (!closed && android.os.SystemClock.elapsedRealtime() < deadline) {
                boolean authorized = false;
                try {
                    client = (SSLSocket) server.accept();
                    client.setSoTimeout(8000);
                    client.startHandshake();
                    BufferedInputStream input = new BufferedInputStream(client.getInputStream());
                    JSONObject hello = new JSONObject(readLine(input));
                    authorized = hello.optInt("v") == 2 && "hello".equals(hello.optString("type"))
                            && MessageDigest.isEqual(token.getBytes(StandardCharsets.US_ASCII),
                            hello.optString("key").getBytes(StandardCharsets.US_ASCII));
                    if (!authorized) {
                        android.util.Log.i("GameLingoTvRelay", "Pairing rejected: incorrect session token");
                        continue;
                    }
                    if (android.os.SystemClock.elapsedRealtime() >= deadline) break;
                    if (closed) return;
                    JSONObject proof = hello.optJSONObject("subscription");
                    PremiumVerifier verifier = new PremiumVerifier();
                    long premiumUntil;
                    listener.subscriptionStatus("Premium abonelik doğrulanıyor…");
                    try { premiumUntil = verifier.verify(proof); }
                    catch (PremiumVerifier.Failure error) {
                        listener.subscriptionStatus("premium_required".equals(error.code)
                                ? "TV altyazıları için aktif Premium gerekiyor. Telefonda satın al veya satın alımları geri yükle."
                                : "Premium doğrulanamadı. Telefon ve TV’nin internetini kontrol edip tekrar dene.");
                        reply(client, new JSONObject().put("v", 2).put("type", "error").put("code", error.code));
                        continue;
                    }
                    if (closed) return;
                    paired = true;
                    android.util.Log.i("GameLingoTvRelay", "Pinned TLS client authenticated");
                    client.setSoTimeout(30000);
                    reply(client, new JSONObject().put("v", 2).put("type", "ready")
                            .put("features", new JSONArray().put("positioned_text_v1"))
                            .put("maxSceneRegions", 128));
                    listener.connected();
                    long lastSequence = 0;
                    long lastFrameId = 0;
                    while (!closed) {
                        JSONObject frame = new JSONObject(readLine(input));
                        if (frame.optInt("v") != 2) throw new IOException("Protocol version");
                        if (verifier.now() >= premiumUntil) {
                            try { premiumUntil = verifier.verify(proof); }
                            catch (PremiumVerifier.Failure error) {
                                endReason = "Premium doğrulanamadığı için TV bağlantısı kapandı. Telefonda aboneliğini ve internetini kontrol et.";
                                reply(client, new JSONObject().put("v", 2).put("type", "error").put("code", error.code));
                                break;
                            }
                        }
                        String type = frame.optString("type");
                        if ("ping".equals(type)) {
                            reply(client, new JSONObject().put("v", 2).put("type", "pong"));
                            continue;
                        }
                        if ("bye".equals(type)) break;
                        long sequence = frame.optLong("seq", 0);
                        if (sequence <= lastSequence) continue;
                        if ("clear".equals(type)) {
                            lastSequence = sequence;
                            listener.caption("", 0, true);
                        } else if ("scene".equals(type)) {
                            TvScene scene = TvScene.parse(frame);
                            lastSequence = sequence;
                            if (scene.frameId <= lastFrameId) continue;
                            lastFrameId = scene.frameId;
                            listener.scene(scene);
                        } else if ("caption".equals(type)) {
                            String text = frame.optString("text").trim();
                            if (text.length() > 500) throw new IOException("Caption too long");
                            lastSequence = sequence;
                            int duration = Math.max(2000, Math.min(15000, frame.optInt("durationMs", 8000)));
                            listener.caption(text, duration, !"bottom".equals(frame.optString("position")));
                        } else throw new IOException("Unknown frame");
                    }
                    break; // One paired phone per user-started session; rescan after disconnect.
                } catch (SocketTimeoutException timeout) {
                    if (authorized) break;
                } catch (Exception invalidClient) {
                    if (invalidClient instanceof SSLException) {
                        android.util.Log.w("GameLingoTvRelay", "TLS handshake failure", invalidClient);
                    }
                    if (authorized || closed) break;
                    // An unpaired client cannot terminate the user's pairing session.
                } finally {
                    SSLSocket old = client;
                    client = null;
                    if (old != null) try { old.close(); } catch (IOException ignored) {}
                }
            }
            if (!closed && !paired && android.os.SystemClock.elapsedRealtime() >= deadline) {
                endReason = "Eşleştirme süresi doldu. Telefonu bağla düğmesine yeniden basın.";
            }
        } catch (Exception error) {
            endReason = "TV bağlantısı açılamadı. Wi-Fi bağlantısını kontrol edip yeniden deneyin.";
            android.util.Log.e("GameLingoTvRelay", "Receiver startup failed", error);
        } finally {
            boolean notify = !closed;
            close();
            if (notify) listener.ended(endReason);
        }
    }
    static String readLine(InputStream input) throws IOException {
        ByteArrayOutputStream line = new ByteArrayOutputStream();
        for (int value; (value = input.read()) != -1;) {
            if (value == '\n') return line.toString(StandardCharsets.UTF_8.name());
            if (line.size() >= 32768) throw new IOException("Frame too large");
            line.write(value);
        }
        throw new EOFException();
    }
    private static void reply(SSLSocket socket, JSONObject value) throws IOException {
        socket.getOutputStream().write((value.toString() + "\n").getBytes(StandardCharsets.UTF_8));
        socket.getOutputStream().flush();
    }
    @Override public void close() {
        closed = true;
        try { if (server != null) server.close(); } catch (IOException ignored) {}
        try { if (client != null) client.close(); } catch (IOException ignored) {}
    }
}
