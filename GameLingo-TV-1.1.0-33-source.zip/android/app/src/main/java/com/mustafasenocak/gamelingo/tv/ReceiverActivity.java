package com.mustafasenocak.gamelingo.tv;

import com.mustafasenocak.gamelingo.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import com.google.zxing.*;
import com.google.zxing.common.BitMatrix;
import java.util.EnumMap;

public final class ReceiverActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status;
    private ImageView qr;
    private Button start;
    private String shownUri = "";
    private final Runnable refresh = new Runnable() {
        @Override public void run() { update(); handler.postDelayed(this, 500); }
    };
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(27), dp(48), dp(27));
        scroll.addView(root);
        setContentView(scroll);
        root.addView(text("Game Lingo", 26, Color.WHITE));
        root.addView(text("Premium aboneliğinle telefonundaki çevirileri TV’de gör.", 18, 0xFFD4C5EE));
        root.addView(text("1. Aynı ağa bağlan  →  2. Altyazı iznini aç  →  3. Telefonu eşleştir", 15, 0xFFB9AAFF));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        row.addView(left, new LinearLayout.LayoutParams(0, -2, 1));
        qr = new ImageView(this);
        qr.setContentDescription("Game Lingo TV eşleştirme QR kodu");
        row.addView(qr, new LinearLayout.LayoutParams(dp(276), dp(276)));
        root.addView(row);
        status = text("", 18, 0xFFD4C5EE);
        left.addView(status);
        Button permission = button("Altyazı gösterme izni");
        permission.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()))); }
            catch (RuntimeException error) {
                Toast.makeText(this, "TV ayarlarından bu uygulamanın üstte görünmesine izin verin.", Toast.LENGTH_LONG).show();
            }
        });
        left.addView(permission);
        start = button("Telefonu bağla");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) { permission.performClick(); return; }
            Intent service = new Intent(this, ReceiverService.class);
            try {
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(service);
                else startService(service);
            } catch (RuntimeException error) {
                ReceiverService.status = "Bağlantı başlatılamadı. TV izinlerini kontrol edip yeniden dene.";
            }
        });
        left.addView(start);
        LinearLayout controls = new LinearLayout(this);
        Button stop = button("Bağlantıyı kapat");
        stop.setOnClickListener(v -> {
            ReceiverService.status = "Bağlantı kapatıldı.";
            stopService(new Intent(this, ReceiverService.class));
        });
        Button help = button("Kurulum / yardım");
        help.setOnClickListener(v -> startActivity(new Intent(this, SetupGuideActivity.class)));
        for (Button control : new Button[]{stop, help}) {
            LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(0, -2, 1);
            layout.setMargins(0, dp(6), dp(20), dp(6));
            controls.addView(control, layout);
        }
        left.addView(controls);
        root.addView(text("Eşleştirdikten sonra konsolun HDMI girişine geç. Çeviriyi telefondaki Game Lingo’dan başlat.", 17, Color.WHITE));
        root.addView(text("Telefonda Premium’u satın al veya satın alımları geri yükle. TV için ikinci abonelik gerekmez. Premium doğrulanmadan altyazı gösterilmez; ücretsiz kamera denemesi TV’de geçerli değildir.", 14, 0xFFBDB0D0));
        Button review = button("İnceleme erişimi / Review access");
        review.setTextSize(14);
        review.setOnClickListener(v -> startActivity(new Intent(this, ReviewAccessActivity.class)));
        root.addView(review);
        (Settings.canDrawOverlays(this) ? start : permission).requestFocus();
        if (state == null && !getSharedPreferences("tv_setup", MODE_PRIVATE).getBoolean("guide_seen_v1", false)) {
            startActivity(new Intent(this, SetupGuideActivity.class));
        }
    }
    @Override public void onResume() { super.onResume(); handler.post(refresh); }
    @Override public void onPause() { handler.removeCallbacks(refresh); super.onPause(); }
    private void update() {
        String message = Settings.canDrawOverlays(this) ? ReceiverService.status
                : "Önce altyazı gösterme iznini aç.";
        if (!message.contentEquals(status.getText())) status.setText(message);
        start.setEnabled(!ReceiverService.running);
        String uri = ReceiverService.pairingUri;
        if (uri.equals(shownUri)) return;
        shownUri = uri;
        if (uri.isEmpty()) { qr.setImageDrawable(null); return; }
        try {
            EnumMap<EncodeHintType, Object> hints = new EnumMap<>(EncodeHintType.class);
            hints.put(EncodeHintType.MARGIN, 4);
            hints.put(EncodeHintType.CHARACTER_SET, "UTF-8");
            BitMatrix matrix = new MultiFormatWriter().encode(uri, BarcodeFormat.QR_CODE, 640, 640, hints);
            int[] pixels = new int[640 * 640];
            for (int y = 0; y < 640; y++) for (int x = 0; x < 640; x++)
                pixels[y * 640 + x] = matrix.get(x, y) ? Color.BLACK : Color.WHITE;
            qr.setImageBitmap(Bitmap.createBitmap(pixels, 640, 640, Bitmap.Config.ARGB_8888));
        } catch (Exception error) {
            status.setText("Eşleştirme kodu oluşturulamadı. Bağlantıyı kapatıp yeniden deneyin.");
        }
    }
    private TextView text(String value, int size, int color) {
        TextView view = new TextView(this);
        view.setText(value); view.setTextSize(size); view.setTextColor(color);
        view.setPadding(0, dp(6), dp(16), dp(6));
        return view;
    }
    private Button button(String label) {
        Button view = new Button(this);
        view.setText(label); view.setAllCaps(false); view.setTextSize(17);
        view.setTextColor(Color.WHITE); view.setMinHeight(dp(48)); view.setFocusable(true);
        StateListDrawable states = new StateListDrawable();
        for (boolean focused : new boolean[]{true, false}) {
            GradientDrawable shape = new GradientDrawable();
            shape.setColor(focused ? 0xFF7543DE : 0xFF282136);
            shape.setCornerRadius(dp(10));
            if (focused) shape.setStroke(dp(2), Color.WHITE);
            states.addState(focused ? new int[]{android.R.attr.state_focused} : new int[]{}, shape);
        }
        view.setBackground(states);
        LinearLayout.LayoutParams layout = new LinearLayout.LayoutParams(-1, -2);
        layout.setMargins(0, dp(6), dp(20), dp(6)); view.setLayoutParams(layout);
        return view;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
