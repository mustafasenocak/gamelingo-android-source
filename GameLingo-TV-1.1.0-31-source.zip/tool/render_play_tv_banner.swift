// Export the existing native TV banner at Google Play's required 1280 × 720.
import AppKit
import CoreText
import ImageIO
import UniformTypeIdentifiers

let width = 1280, height = 720
guard CommandLine.arguments.count == 2,
      let source = CGImageSourceCreateWithURL(URL(fileURLWithPath:
        "android/app/src/main/res/drawable-nodpi/ic_launcher_artwork.png") as CFURL, nil),
      let image = CGImageSourceCreateImageAtIndex(source, 0, nil),
      let cg = CGContext(data: nil, width: width, height: height,
        bitsPerComponent: 8, bytesPerRow: width * 4,
        space: CGColorSpaceCreateDeviceRGB(), bitmapInfo: CGImageAlphaInfo.noneSkipLast.rawValue) else {
    fatalError("A banner output path and the approved artwork are required")
}
cg.setFillColor(CGColor(red: 11/255, green: 7/255, blue: 24/255, alpha: 1))
cg.fill(CGRect(x: 0, y: 0, width: width, height: height))
cg.draw(image, in: CGRect(x: 40, y: 80, width: 560, height: 560))
let attributes: [NSAttributedString.Key: Any] = [
    .font: NSFont(name: "HelveticaNeue-Bold", size: 144)!,
    .foregroundColor: NSColor(red: 248/255, green: 244/255, blue: 1, alpha: 1),
]
for (label, baseline): (String, CGFloat) in [("Game", 392), ("Lingo", 220)] {
    let line = CTLineCreateWithAttributedString(NSAttributedString(string: label, attributes: attributes))
    cg.textPosition = CGPoint(x: 652, y: baseline)
    CTLineDraw(line, cg)
}
guard let output = cg.makeImage(), let destination = CGImageDestinationCreateWithURL(
    URL(fileURLWithPath: CommandLine.arguments[1]) as CFURL, UTType.png.identifier as CFString, 1, nil)
    else { fatalError("PNG failed") }
CGImageDestinationAddImage(destination, output, nil)
guard CGImageDestinationFinalize(destination) else { fatalError("PNG export failed") }
print("TV banner exported: 1280 × 720, RGB, approved artwork and native wordmark.")
