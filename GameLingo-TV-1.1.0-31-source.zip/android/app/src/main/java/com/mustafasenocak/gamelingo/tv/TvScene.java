package com.mustafasenocak.gamelingo.tv;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/** A bounded snapshot; coordinates refer to the original, uncropped game frame. */
final class TvScene {
    static final class Region {
        final String text;
        final float x, y, w, h;
        final float[] cover;
        Region(String text, float x, float y, float w, float h, float[] cover) {
            this.text = text; this.x = x; this.y = y; this.w = w; this.h = h;
            this.cover = cover;
        }
    }
    final long frameId;
    final int width, height, durationMs;
    final List<Region> regions;
    private TvScene(long frameId, int width, int height, int durationMs, List<Region> regions) {
        this.frameId = frameId; this.width = width; this.height = height;
        this.durationMs = durationMs; this.regions = Collections.unmodifiableList(regions);
    }
    static TvScene parse(JSONObject value) throws JSONException {
        long frameId = value.getLong("frameId");
        int width = value.getInt("sourceWidth"), height = value.getInt("sourceHeight");
        int duration = value.getInt("durationMs");
        JSONArray items = value.getJSONArray("regions");
        if (frameId <= 0 || width < 1 || height < 1 || width > 8192 || height > 8192
                || duration < 500 || duration > 4000 || items.length() > 128) {
            throw new JSONException("Invalid scene size");
        }
        List<Region> regions = new ArrayList<>();
        HashSet<String> ids = new HashSet<>();
        int characters = 0;
        for (int i = 0; i < items.length(); i++) {
            JSONObject item = items.getJSONObject(i);
            String id = item.getString("id"), text = item.getString("text").trim();
            float x = coordinate(item, "x"), y = coordinate(item, "y");
            float w = coordinate(item, "w"), h = coordinate(item, "h");
            characters += text.length();
            if (id.isEmpty() || id.length() > 64 || !ids.add(id) || text.isEmpty()
                    || text.length() > 500 || characters > 6000 || w <= 0 || h <= 0
                    || x + w > 1.000001f || y + h > 1.000001f) {
                throw new JSONException("Invalid text region");
            }
            float[] cover = null;
            if (item.has("cover")) {
                JSONObject original = item.getJSONObject("cover");
                float cx = coordinate(original, "x"), cy = coordinate(original, "y");
                float cw = coordinate(original, "w"), ch = coordinate(original, "h");
                if (cw <= 0 || ch <= 0 || cx + cw > 1.000001f || cy + ch > 1.000001f) {
                    throw new JSONException("Invalid original subtitle bounds");
                }
                cover = new float[]{cx, cy, cw, ch};
            }
            regions.add(new Region(text, x, y, w, h, cover));
        }
        return new TvScene(frameId, width, height, duration, regions);
    }
    private static float coordinate(JSONObject value, String key) throws JSONException {
        Object raw = value.get(key);
        if (!(raw instanceof Number)) throw new JSONException("Invalid coordinate type");
        double n = ((Number) raw).doubleValue();
        if (Double.isNaN(n) || Double.isInfinite(n) || n < 0 || n > 1) {
            throw new JSONException("Invalid coordinate range");
        }
        return (float) n;
    }
}
