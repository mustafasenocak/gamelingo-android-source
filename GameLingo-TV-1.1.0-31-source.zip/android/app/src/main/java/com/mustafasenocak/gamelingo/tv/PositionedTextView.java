package com.mustafasenocak.gamelingo.tv;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.Layout;
import android.text.StaticLayout;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.View;

/** Renders translated boxes without receiving any controller or touch input. */
final class PositionedTextView extends View {
    private TvScene scene;
    private final Paint background = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint textPaint = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    PositionedTextView(Context context, TvScene scene) {
        super(context);
        this.scene = scene;
        // Opaque fill hides the original game subtitle, including while a
        // newer English sentence waits behind the current Turkish caption.
        background.setColor(0xFF100C1C);
        textPaint.setColor(Color.WHITE);
        textPaint.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        float density = getResources().getDisplayMetrics().density;
        textPaint.setShadowLayer(density, 0, density / 2, Color.BLACK);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        setFocusable(false);
    }
    void setScene(TvScene nextScene) {
        scene = nextScene;
        invalidate();
    }
    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float scale = Math.min(getWidth() / (float) scene.width, getHeight() / (float) scene.height);
        float contentWidth = scene.width * scale, contentHeight = scene.height * scale;
        float offsetX = (getWidth() - contentWidth) / 2, offsetY = (getHeight() - contentHeight) / 2;
        for (TvScene.Region region : scene.regions) {
            RectF box = new RectF(offsetX + region.x * contentWidth, offsetY + region.y * contentHeight,
                    offsetX + (region.x + region.w) * contentWidth,
                    offsetY + (region.y + region.h) * contentHeight);
            float padding = Math.min(6 * getResources().getDisplayMetrics().density,
                    Math.min(box.width(), box.height()) * .08f);
            int width = Math.max(1, Math.round(box.width() - 2 * padding));
            float availableHeight = Math.max(1, box.height() - 2 * padding);
            float maxSize = Math.min(20 * getResources().getDisplayMetrics().scaledDensity, availableHeight * .8f);
            float minSize = Math.min(maxSize, 9 * getResources().getDisplayMetrics().scaledDensity);
            StaticLayout layout = layout(region.text, width, maxSize);
            float size = maxSize;
            while ((layout.getHeight() > availableHeight ||
                    layout.getEllipsisCount(layout.getLineCount() - 1) > 0) && size > minSize) {
                size = Math.max(minSize, size - 1);
                layout = layout(region.text, width, size);
            }
            float drawX = box.left + padding;
            float drawY = box.top + padding + Math.max(0, (availableHeight - layout.getHeight()) / 2);
            RectF backdrop = new RectF(box);
            if (region.cover != null) {
                RectF original = new RectF(offsetX + region.cover[0] * contentWidth,
                        offsetY + region.cover[1] * contentHeight,
                        offsetX + (region.cover[0] + region.cover[2]) * contentWidth,
                        offsetY + (region.cover[1] + region.cover[3]) * contentHeight);
                float inkWidth = 1;
                for (int line = 0; line < layout.getLineCount(); line++) {
                    inkWidth = Math.max(inkWidth, layout.getLineWidth(line));
                }
                float centerX = Math.max(offsetX + padding + inkWidth / 2,
                        Math.min(offsetX + contentWidth - padding - inkWidth / 2, original.centerX()));
                float centerY = Math.max(box.top + padding + layout.getHeight() / 2f,
                        Math.min(box.bottom - padding - layout.getHeight() / 2f, original.centerY()));
                drawX = centerX - width / 2f;
                drawY = centerY - layout.getHeight() / 2f;
                backdrop.set(centerX - inkWidth / 2, drawY,
                        centerX + inkWidth / 2, drawY + layout.getHeight());
                backdrop.union(original);
                backdrop.inset(-padding, -padding);
                backdrop.intersect(offsetX, offsetY, offsetX + contentWidth, offsetY + contentHeight);
            }
            canvas.drawRoundRect(backdrop, padding, padding, background);
            int saved = canvas.save();
            canvas.clipRect(region.cover == null ? box : backdrop);
            canvas.translate(drawX, drawY);
            layout.draw(canvas);
            canvas.restoreToCount(saved);
        }
    }
    private StaticLayout layout(String text, int width, float size) {
        textPaint.setTextSize(Math.max(1, size));
        return StaticLayout.Builder.obtain(text, 0, text.length(), textPaint, width)
                .setAlignment(Layout.Alignment.ALIGN_CENTER).setIncludePad(false)
                .setMaxLines(6).setEllipsize(TextUtils.TruncateAt.END).build();
    }
}
