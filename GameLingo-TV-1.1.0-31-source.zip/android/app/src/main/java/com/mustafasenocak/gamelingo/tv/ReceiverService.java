package com.mustafasenocak.gamelingo.tv;

import com.mustafasenocak.gamelingo.R;

import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.os.*;
import android.provider.Settings;
import android.view.*;
import android.widget.TextView;

public final class ReceiverService extends Service {
    static volatile boolean running;
    static volatile String pairingUri = "";
    static volatile String status = "Telefon ve TV aynı Wi-Fi ağına bağlı olmalı.";
    static final String PREVIEW = "com.mustafasenocak.gamelingo.tv.PREVIEW";
    private static final String STOP = "com.mustafasenocak.gamelingo.tv.STOP";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private PairingServer server;
    private volatile boolean destroyed;
    private WindowManager windows;
    private View caption;
    private boolean captionAdded;
    private final Runnable clear = this::clearCaption;

    @Override public void onCreate() {
        super.onCreate();
        windows = getSystemService(WindowManager.class);
        if (Build.VERSION.SDK_INT >= 26) getSystemService(NotificationManager.class).createNotificationChannel(
                new NotificationChannel("tv_relay", "TV altyazısı", NotificationManager.IMPORTANCE_LOW));
    }
    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && STOP.equals(intent.getAction())) { stopSelf(); return START_NOT_STICKY; }
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return START_NOT_STICKY; }
        // A setup preview must never interrupt an existing paired session.
        if (running) return START_NOT_STICKY;
        boolean preview = intent != null && PREVIEW.equals(intent.getAction());
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, ReceiverActivity.class), PendingIntent.FLAG_IMMUTABLE);
        PendingIntent stop = PendingIntent.getService(this, 1,
                new Intent(this, ReceiverService.class).setAction(STOP), PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "tv_relay") : new Notification.Builder(this);
        Notification notification = builder
                .setSmallIcon(R.drawable.ic_tv_notification).setContentTitle("Game Lingo")
                .setContentText(preview ? "15 saniyelik örnek altyazı açık." : "TV altyazı bağlantısı açık.")
                .setContentIntent(open).setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "Bağlantıyı kapat", stop).build()).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(74, notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(74, notification);
        if (server != null) return START_NOT_STICKY;
        running = true;
        if (preview) {
            pairingUri = "";
            status = "Örnek altyazı 15 saniye açık. HDMI girişine geçerek TV uyumunu da kontrol edebilirsin.";
            showCaption("Bu bir örnek altyazıdır.", 15000, false);
            handler.postDelayed(() -> {
                status = "Örnek altyazı sona erdi. Gerçek çeviri için telefonunu eşleştir.";
                stopSelf();
            }, 15000);
            return START_NOT_STICKY;
        }
        status = "TV bağlantısı hazırlanıyor…";
        server = new PairingServer(this, new PairingServer.Listener() {
            public void pairing(String uri) { handler.post(() -> {
                if (!running || destroyed) return;
                pairingUri = uri;
                status = "Game Lingo’da TV’ye bağlan → TV kodunu tara. Kod 5 dakika geçerlidir.";
            }); }
            public void connected() { handler.post(() -> {
                if (!running || destroyed) return;
                pairingUri = "";
                status = "Telefon bağlandı. Şimdi kumandadan konsolun HDMI girişine geçebilirsiniz.";
            }); }
            public void caption(String text, int duration, boolean top) { handler.post(() -> {
                if (running && !destroyed) showCaption(text, duration, top);
            }); }
            public void scene(TvScene scene) { handler.post(() -> {
                if (running && !destroyed) showScene(scene);
            }); }
            public void ended(String reason) { handler.post(() -> {
                if (destroyed) return;
                status = reason;
                stopSelf();
            }); }
        });
        server.start();
        handler.postDelayed(() -> {
            status = "İki saatlik oturum sona erdi. Yeniden eşleştirebilirsiniz.";
            stopSelf();
        }, 2 * 60 * 60 * 1000L);
        return START_NOT_STICKY;
    }
    private void showCaption(String text, int duration, boolean top) {
        handler.removeCallbacks(clear);
        clearCaption();
        if (text.isEmpty()) return;
        try {
            TextView textView = new TextView(this);
            caption = textView;
            textView.setText(text);
            textView.setTextSize(24);
            textView.setTextColor(Color.WHITE);
            textView.setShadowLayer(dp(1), 0, 1, Color.BLACK);
            textView.setTypeface(null, Typeface.BOLD);
            textView.setMaxLines(4);
            textView.setGravity(Gravity.CENTER);
            textView.setPadding(dp(18), dp(10), dp(18), dp(10));
            android.util.DisplayMetrics display = getResources().getDisplayMetrics();
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    Math.round(display.widthPixels * .85f), WindowManager.LayoutParams.WRAP_CONTENT,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                    PixelFormat.TRANSLUCENT);
            params.gravity = (top ? Gravity.TOP : Gravity.BOTTOM) | Gravity.CENTER_HORIZONTAL;
            params.y = Math.round(display.heightPixels * .12f);
            params.alpha = 1f;
            params.setTitle("Game Lingo paired subtitle");
            windows.addView(caption, params);
            captionAdded = true;
            handler.postDelayed(clear, duration);
        } catch (RuntimeException error) {
            status = "Altyazı gösterilemedi. TV’nin üstte gösterme iznini kontrol edin.";
            stopSelf();
        }
    }
    private void showScene(TvScene scene) {
        handler.removeCallbacks(clear);
        if (scene.regions.isEmpty()) { clearCaption(); return; }
        try {
            if (caption instanceof PositionedTextView && captionAdded) {
                ((PositionedTextView) caption).setScene(scene);
                handler.postDelayed(clear, scene.durationMs);
                return;
            }
            clearCaption();
            caption = new PositionedTextView(this, scene);
            WindowManager.LayoutParams params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                    Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                            : WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            params.gravity = Gravity.TOP | Gravity.LEFT;
            params.alpha = 1f;
            params.setTitle("Game Lingo positioned translations");
            windows.addView(caption, params);
            captionAdded = true;
            handler.postDelayed(clear, scene.durationMs);
        } catch (RuntimeException error) {
            status = "Çeviri konumları gösterilemedi. TV iznini kontrol edin.";
            stopSelf();
        }
    }
    private void clearCaption() {
        // addView can return before View attachment. Checking isAttachedToWindow
        // here leaks a window when two scene messages arrive in the same frame.
        if (caption != null && captionAdded) windows.removeViewImmediate(caption);
        captionAdded = false;
        caption = null;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
    @Override public void onDestroy() {
        destroyed = true;
        running = false;
        pairingUri = "";
        handler.removeCallbacksAndMessages(null);
        if (server != null) server.close();
        server = null;
        clearCaption();
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
