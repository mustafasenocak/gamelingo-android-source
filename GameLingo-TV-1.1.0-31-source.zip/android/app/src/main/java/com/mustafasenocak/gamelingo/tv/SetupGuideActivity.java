package com.mustafasenocak.gamelingo.tv;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;
import java.net.Inet4Address;

/** D-pad-only setup, available again from the receiver at any time. */
public final class SetupGuideActivity extends Activity {
    private int step;
    private TextView progress, title, description, state;
    private Button action, next, back;
    private final String[] titles = {
        "Telefon çevirir, TV gösterir", "İki cihazı aynı ağa bağla",
        "Altyazı gösterme iznini aç", "Telefonunu QR koduyla eşleştir",
        "Oyuna dön ve çeviriyi başlat"
    };
    private final String[] descriptions = {
        "Telefonuna da Game Lingo’yu yükle. Türkçe çeviri telefonda hazırlanır; TV yalnızca eşleştirdiğin telefondan gelen yazıyı gösterir. Seslendirme telefondan gelir. Kurulum için bilgisayar gerekmez.",
        "Telefonu ve bu TV’yi aynı ev modemine bağla. TV Ethernet ile de bağlanabilir. Misafir Wi-Fi ağı cihazların birbirini görmesini engelleyebilir. Telefonun çeviri ve ses için internet bağlantısı da açık olmalı.",
        "Aşağıdaki düğmeyle TV ayarlarını aç. Game Lingo için “Diğer uygulamaların üzerinde göster” iznini etkinleştir ve kumandanın geri tuşuyla buraya dön. Bu izin, altyazıyı HDMI oyun görüntüsünün üzerinde göstermek için gerekir. Rehberi bitirince “Altyazıyı dene (telefonsuz)” ile 15 saniyelik örnek yazıyı gösterip HDMI girişinde kontrol edebilirsin.",
        "Bu rehberden sonra “Telefonu bağla”ya bas. Telefonda Game Lingo → TV simgesi → “TV kodunu tara” yolunu aç ve bu TV’nin QR kodunu okut. Kamera izni QR içindir; yerel ağ izni sorulursa izin ver. Kod 5 dakika geçerlidir. Birden fazla TV varsa doğru ekranın kodunu tara.",
        "Telefonda “TV’ye test yazısı gönder” ile kontrol et. Sonra TV kumandasıyla konsolun HDMI girişine geç. PS5 çevirisinde Altyazı/İkisi modunu ve “Altyazıyı TV’ye de gönder”i aç. Kamera çevirisinde özgün oyun altyazısını tara. Game Lingo telefonda açık kalsın; ses telefondan gelir."
    };

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        if (saved != null) step = Math.max(0, Math.min(4, saved.getInt("step")));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(48), dp(28), dp(48), dp(28));
        setContentView(root);
        root.addView(label("Game Lingo · TV kurulumu", 20, 0xFFD4C5EE));
        progress = label("", 15, 0xFFB9AAFF); root.addView(progress);
        title = label("", 26, Color.WHITE); root.addView(title);
        ScrollView scroll = new ScrollView(this);
        description = label("", 19, Color.WHITE);
        description.setLineSpacing(dp(3), 1f);
        scroll.addView(description);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        state = label("", 16, 0xFFB9AAFF); root.addView(state);
        action = button(""); root.addView(action);
        action.setOnClickListener(v -> openSettings());
        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.END);
        back = button("Geri"); next = button("Devam et");
        controls.addView(back, new LinearLayout.LayoutParams(0, dp(50), 1));
        controls.addView(next, new LinearLayout.LayoutParams(0, dp(50), 1));
        root.addView(controls);
        back.setOnClickListener(v -> { if (step == 0) finish(); else { step--; render(); } });
        next.setOnClickListener(v -> {
            if (step == 4) {
                getSharedPreferences("tv_setup", MODE_PRIVATE).edit().putBoolean("guide_seen_v1", true).apply();
                finish();
            } else { step++; render(); }
        });
        render();
    }
    @Override public void onResume() { super.onResume(); if (state != null) renderState(); }
    @Override public void onSaveInstanceState(Bundle state) { state.putInt("step", step); super.onSaveInstanceState(state); }
    private void render() {
        progress.setText("Adım " + (step + 1) + " / 5");
        title.setText(titles[step]); description.setText(descriptions[step]);
        action.setVisibility(step == 1 || step == 2 ? android.view.View.VISIBLE : android.view.View.GONE);
        action.setText(step == 1 ? "TV ağ ayarlarını aç" : "Altyazı gösterme izni");
        next.setText(step == 4 ? "Eşleştirme ekranını aç" : "Devam et");
        back.setText(step == 0 ? "Rehberi kapat" : "Geri");
        renderState(); next.requestFocus();
    }
    private void renderState() {
        if (step == 1) {
            ConnectivityManager manager = getSystemService(ConnectivityManager.class);
            LinkProperties links = manager.getLinkProperties(manager.getActiveNetwork());
            String address = links == null ? "" : links.getLinkAddresses().stream()
                .map(a -> a.getAddress()).filter(a -> a instanceof Inet4Address && a.isSiteLocalAddress())
                .map(a -> a.getHostAddress()).findFirst().orElse("");
            state.setText(address.isEmpty() ? "Yerel ağ bağlantısı bulunamadı. TV ağ ayarlarını kontrol et."
                : android.os.Build.MODEL + " · TV adresi: " + address);
        } else if (step == 2) state.setText(Settings.canDrawOverlays(this) ? "Altyazı izni açık. Devam edebilirsin." : "Altyazı izni henüz kapalı.");
        else if (step == 4) state.setText("Oturum 2 saat sonra kapanır. TV’de Game Lingo’yu açarak yeniden eşleştirebilirsin.");
        else state.setText("");
    }
    private void openSettings() {
        Intent intent = step == 1 ? new Intent(Settings.ACTION_WIFI_SETTINGS)
            : new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
        try { startActivity(intent); }
        catch (RuntimeException e) {
            Toast.makeText(this, step == 1 ? "Kumandadan TV Ayarları → Ağ ve internet bölümünü aç."
                : "TV Ayarları → Uygulamalar → Özel uygulama erişimi → Diğer uygulamaların üzerinde göster bölümünü aç.", Toast.LENGTH_LONG).show();
        }
    }
    private TextView label(String value, int size, int color) {
        TextView v = new TextView(this); v.setText(value); v.setTextSize(size); v.setTextColor(color);
        v.setPadding(0, dp(6), 0, dp(6)); return v;
    }
    private Button button(String value) {
        Button v = new Button(this); v.setText(value); v.setTextSize(17); v.setTextColor(Color.WHITE);
        v.setAllCaps(false); v.setFocusable(true); v.setMinHeight(dp(48));
        StateListDrawable states = new StateListDrawable();
        for (boolean focused : new boolean[]{true, false}) {
            GradientDrawable shape = new GradientDrawable(); shape.setCornerRadius(dp(8));
            shape.setColor(focused ? 0xFF7543DE : 0xFF282136);
            if (focused) shape.setStroke(dp(2), Color.WHITE);
            states.addState(focused ? new int[]{android.R.attr.state_focused} : new int[]{}, shape);
        }
        v.setBackground(states); return v;
    }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
