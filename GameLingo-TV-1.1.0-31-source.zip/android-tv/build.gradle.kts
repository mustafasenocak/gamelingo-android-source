plugins { id("com.android.application") version "9.0.1" apply false }
layout.buildDirectory.set(file("../build/android-tv"))
subprojects { layout.buildDirectory.set(rootProject.layout.buildDirectory.dir(name)) }
